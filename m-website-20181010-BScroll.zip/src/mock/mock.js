const list = require('./list.json')
const refresh = require('./refresh.json')

module.exports = function() {
  return {
    list,
    refresh
  }
}